﻿using BookShop.Data;

using BookShop.Initializer;
using System;
using System.Linq;

namespace BookShop
{
   public class StartUp
    {
        static void Main(string[] args)
        {
           
            var context = new BookShopContext();
            DbInitializer.ResetDatabase(context);
            Console.WriteLine(GetBooksByAgeRestriction(context, "miNor"));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            if (command == null)
            {
                command = Console.ReadLine();
            }

            return string.Join(Environment.NewLine, context.Books.ToList()
                .Where(b => b.AgeRestriction.ToString().Equals(command, StringComparison.OrdinalIgnoreCase))
                .Select(b => b.Title)
                .OrderBy(t => t));
        }
    }
}
