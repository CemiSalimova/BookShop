﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.Models.Enums
{
   public enum AgeRestriction
    {
        Minor,
        Teen, 
        Adult
    }
}
