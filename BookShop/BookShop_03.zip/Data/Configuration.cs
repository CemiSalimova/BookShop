﻿namespace BookShop.Data
{
internal  class Configuration
    {
   internal static string ConnectionString =
            @"Server=DESKTOP-M8B0TGR\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}
