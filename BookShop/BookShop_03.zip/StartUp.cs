﻿using BookShop.Data;

using BookShop.Initializer;
using System;
using System.Linq;
using System.Text;

namespace BookShop
{
   public class StartUp
    {
        static void Main(string[] args)
        {
           
            var context = new BookShopContext();
            //DbInitializer.ResetDatabase(context);
            // Console.WriteLine(GetBooksByAgeRestriction(context, "miNor"));
            // Console.WriteLine(GetGoldenBooks(context));
            Console.WriteLine(GetBooksByPrice(context));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            if (command == null)
            {
                command = Console.ReadLine();
            }

            return string.Join(Environment.NewLine, context.Books.ToList()
                .Where(b => b.AgeRestriction.ToString().Equals(command, StringComparison.OrdinalIgnoreCase))
                .Select(b => b.Title)
                .OrderBy(t => t));
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
           
            return string.Join(Environment.NewLine, context.Books.ToList().OrderBy(b=>b.BookId)
                .Where(b => b.Copies<5000 && b.EditionType==Models.Enums.EditionType.Gold)
                .Select(b=>b.Title)
                );
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var books = context.Books.Where(b => b.Price > 40)
                .Select(a => new
                {
                    BookTitle = a.Title,
                    BookPrice = a.Price
                }
                ).ToList();
            foreach (var b in books.OrderByDescending(p=>p.BookPrice))
            {
                sb.AppendLine($"{b.BookTitle} - ${b.BookPrice:f2}");
            }
            return sb.ToString().TrimEnd();
        }
    }
}
