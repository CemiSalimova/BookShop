﻿using BookShop.Data;

using BookShop.Initializer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookShop
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            var context = new BookShopContext();
            var input = Console.ReadLine();
            //DbInitializer.ResetDatabase(context);
            // Console.WriteLine(GetBooksByAgeRestriction(context, "miNor"));
            // Console.WriteLine(GetGoldenBooks(context));
            //  Console.WriteLine(GetBooksByPrice(context));
            // Console.WriteLine(GetBooksNotReleasedIn(context,1998));
            Console.WriteLine(GetBooksByCategory(context,input));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            if (command == null)
            {
                command = Console.ReadLine();
            }

            return string.Join(Environment.NewLine, context.Books.ToList()
                .Where(b => b.AgeRestriction.ToString().Equals(command, StringComparison.OrdinalIgnoreCase))
                .Select(b => b.Title)
                .OrderBy(t => t));
        }
        public static string GetGoldenBooks(BookShopContext context)
        {

            return string.Join(Environment.NewLine, context.Books.ToList().OrderBy(b => b.BookId)
                .Where(b => b.Copies < 5000 && b.EditionType == Models.Enums.EditionType.Gold)
                .Select(b => b.Title)
                );
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();
            var books = context.Books.Where(b => b.Price > 40)
                .Select(a => new
                {
                    BookTitle = a.Title,
                    BookPrice = a.Price
                }
                ).ToList();
            foreach (var b in books.OrderByDescending(p => p.BookPrice))
            {
                sb.AppendLine($"{b.BookTitle} - ${b.BookPrice:f2}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            StringBuilder sb = new StringBuilder();

            var books = context.Books.Where(b => b.ReleaseDate.Value.Year != year && b.ReleaseDate != null)
                .Select(a => new
                {
                    BookTitle=a.Title
                }
                ).ToList();
            foreach (var b in books)
            {
                sb.AppendLine($"{b.BookTitle}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            List<string> singleLine = input.Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Select(c=>c.ToLower()).ToList();
            StringBuilder sb = new StringBuilder();
            List<string> bookLists = new List<string>();
            for (int i = 0; i < singleLine.Count; i++)
            {
                var books = context.Books.Where(b => b.BookCategories.Any(a => a.Category.Name == singleLine[i].ToLower())).Select(t => t.Title).ToList();
                foreach (var b in books)
                {
                    bookLists.Add(b);
                }
            }
            foreach (var b in bookLists.OrderBy(t => t))
            {
                sb.AppendLine(b);
            }

            return sb.ToString().TrimEnd();

        }
        //public static string GetBooksByCategory(BookShopContext context, string input)
        //{
        //    List<string> categories = input
        //        .Split(" ", StringSplitOptions.RemoveEmptyEntries)
        //        .Select(c => c.ToLower())
        //        .ToList();

        //    List<string> bookTitles = new List<string>();

        //    foreach (var category in categories)
        //    {

        //        List<string> currentCategoryBooks = context.
        //            Books
        //            .Where(b => b.BookCategories.Any(bc => bc.Category.Name.ToLower() == category))
        //            .Select(b => b.Title)
        //            .ToList();
        //        bookTitles.AddRange(currentCategoryBooks);
        //    }

        //    return string.Join(Environment.NewLine, bookTitles.OrderBy(b => b));
        //}

    }
}
